import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class LiftOff extends JPanel {

	private static final int width = 500;
	private static final int height = 500;
	
	private BufferedImage image;
	private Graphics g;
	private Rocket rocket;
	//private int wind;
	private Timer timer;
	
	public LiftOff() {
		
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		g = image.getGraphics();
		
		GraphicsUtilities.drawBackground(g, Color.BLUE, width, height);
		
		rocket = new Rocket(225, 300, 75, 200, Color.DARK_GRAY);
		rocket.setySpeed(-1);
		rocket.draw(g);
		
		timer = new Timer(5, new TimerListener());
		timer.start();
		
	}
	
	private class TimerListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
			GraphicsUtilities.drawBackground(g, Color.BLUE, width, height);
			
			//wind+=1;
			//rocket = new Rocket(225, 300, 75, 200, Color.DARK_GRAY);
			rocket.move(height);
			rocket.draw(g);
			
			repaint();
		}
	}

	
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("LiftOff");
		frame.setSize(width, height);
		frame.setLocation(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new LiftOff());
		frame.setVisible(true);
	}
	
	
}