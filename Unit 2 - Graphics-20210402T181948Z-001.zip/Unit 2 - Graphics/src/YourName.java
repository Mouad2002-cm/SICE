
public class YourName {

}
