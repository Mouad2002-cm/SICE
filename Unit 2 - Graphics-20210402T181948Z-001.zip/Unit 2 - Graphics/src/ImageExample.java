import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class ImageExample extends JPanel{
	
	private static final int width = 800;
	private static final int height = 400;
	
	private BufferedImage bufferedImage;
	
	public ImageExample() {
		bufferedImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		Graphics g = bufferedImage.getGraphics();
		
		ImageIcon image = new ImageIcon("WAYDE.jpg");
		g.drawImage(image.getImage(),width/2,height/2,width/2,height/2,null);
	}

	public void paintComponent(Graphics g) {
		g.drawImage(bufferedImage, 0, 0, width, height, null);
	}
	
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame("Imported Image Example");
		frame.setSize(500, 500);
		frame.setLocation(300,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new ImageExample());
		frame.setVisible(true);
		
	}
	
}
