import java.awt.Color;
import java.awt.Graphics;

public class Snowflake {

	private int x;
	private int y;
	
	public Snowflake(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.WHITE);
		g.drawOval(x - 5, y - 5, 10, 10);
		g.drawLine(x + 5, y + 5, x + 8, y + 8);
		g.drawLine(x - 5, y + 5, x - 8, y + 8);
		g.drawLine(x + 5, y - 5, x + 8, y - 8);
		g.drawLine(x - 5, y - 5, x - 8, y - 8);
		g.drawLine(x + 5, y, x + 10, y);
		g.drawLine(x - 5, y, x - 10, y);
		g.drawLine(x, y + 5, x, y + 10);
		g.drawLine(x, y - 5, x, y - 10);
	}
	
}
