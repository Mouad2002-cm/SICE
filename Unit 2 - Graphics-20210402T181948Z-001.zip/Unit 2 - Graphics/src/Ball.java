import java.awt.Color;
import java.awt.Graphics;

public class Ball {

	// 1. Declaration of Variables
	
	private double x;			//x-coordinate of the center of the ball
	private double y;			//y-coordinate of the center of the ball
	private double diameter;	//diameter of the ball
	private double radius;		//radius of the ball = diameter/2
	private Color color;		//color of the ball
	private double xSpeed;		//x-speed = change in x-position
	private double ySpeed;		//y-speed = change in y-position

	
	// 2. Create a default constructor
	/**
	 * Default Constructor
	 * Creates a red ball at (0, 0) with a diameter of 25.  
	 * The default speed is 0.
	 */
	
	public Ball() {
		x = 0;
		y = 0;
		diameter = 25;
		radius = diameter/2.0;
		color = Color.RED;
		xSpeed = 0;
		ySpeed = 0;	
	}
	
	// 3. Write a constructor that allows the user to input the parameters (x, y, diameter, Color)
		// and sets the x and y-speed = 0.  Comment with javadoc.
	
	/**
	 * Constructor that takes in
	 * x, y, diameter, and color 
	 * The default speed is 0.
	 */
	public Ball(double x, double y, double diameter, Color color) {
		this.x = x;
		this.y = y;
		this.diameter = diameter;
		this.radius = diameter/2.0;
		this.color = color;
		this.xSpeed = 0;
		this.ySpeed = 0;
	}

	
	// 4. Create getters and setters for all private variables
	// Comment with javadoc
	
	public void setX(double x) {
		this.x = x;
	}
	
	public double getX() {
		return x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public double getY() {
		return y;
	}
	
	public void setxSpeed(double xSpeed) {
		this.xSpeed = xSpeed;
	}
	
	public double getxSpeed() {
		return xSpeed;
	}
	
	public void setySpeed(double ySpeed) {
		this.ySpeed = ySpeed;
	}
	
	public double getySpeed() {
		return ySpeed;
	}
	
	public void setDiameter(double diameter) {
		this.diameter = diameter;
		this.radius = diameter/2;
	}
	
	
	public double getDiameter() {
		return diameter;
	}
	
	public void setRadius(double radius) {
		this.radius = radius;
		this.diameter = 2*radius;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public void setColor(Color color) {
		this.color = color;
	}
	
	public Color getColor() {
		return color;
	}

	
	// 5. Finish the following methods
	// 6. Test using BouncingBallTester.java
	/**
	 * Comment...
	 * @param g
	 */
	public void draw(Graphics g) {

		g.setColor(color);
		g.fillOval((int)(x - radius), (int)(y - radius), (int)diameter, (int)diameter);
		
	}
	
	
	
	/**
	 * Sets the center location of the ball
	 * @param x
	 * @param y
	 */
	public void setLocation(double x, double y) {
	
		this.x = x;
		this.y = y;
		
	}
	
	
	/**
	 * Generates a speed between -<code>maxSpeed<code>
	 * and <code>maxSpeed<code>
	 * @param maxSpeed
	 */
	public void setRandomSpeed(double maxSpeed) {
		xSpeed = Math.random() * maxSpeed;
		ySpeed = Math.random() * maxSpeed;
		
	}

	
	//7. Write the move method to make the ball move around the screen
	// and bounce of the edges.
	/**
	 * Comment....
	 * @param rightEdge
	 * @param bottomEdge
	 */
	public void move(int rightEdge, int bottomEdge) {
		setX(getX() + getxSpeed());
	    setY(getY() + getySpeed());
		
		//right edge
		if(rightEdge - getX() < getRadius()) {
			setX(rightEdge - getRadius());
			setxSpeed(getxSpeed() * -1);
		}
		
		//left edge
		if(getX() <= getRadius()) {
			setX(radius);
			setxSpeed(getxSpeed() * -1);
		}
		
		//bottom edge
		if(bottomEdge - getY() < getRadius()) {
			setY(bottomEdge - getRadius());
			setySpeed(getySpeed() * -1);
		}
		
		//top edge
		if(getY() <= radius) {
			setY(radius);
			setySpeed(getySpeed() * -1);
		}
		
	}
}

