import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class Falcon9LiftOff extends JPanel {

	//Sets width and height of frame
	private static final int width = 523;
	private static final int height = 1000;
	
	//Declares global variables
	private BufferedImage image;
	private Graphics g;
	private Falcon9 rocket;
	private Timer timer;
	
	public Falcon9LiftOff() {
		
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		g = image.getGraphics();
		
		//Draws a ground and a dark blue sky
		GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
		GraphicsUtilities.drawBackground(g, Color.BLUE.darker().darker(), width, 800);
		
		//Creates and draws rocket and establishes time
		rocket = new Falcon9((width/2)-10, 700, 33, 100, Color.DARK_GRAY);
		rocket.setDeltaTime(0.05);
		rocket.draw(g);
		
		//Set and starts timer as well as sync to delta time
		timer = new Timer(5, new TimerListener());
		timer.start();
		
	}
	
	private class TimerListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
			//Ground and sky
			GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
			GraphicsUtilities.drawBackground(g, Color.BLUE.darker().darker(), width, 800);
			
			//Strings
			String pattern = "#.####";
			DecimalFormat numberFormat = new DecimalFormat(pattern);
			
			g.setColor(Color.WHITE);
			g.setFont(new Font("Serif", Font.BOLD, 18));
			g.drawString("Altitude: " + numberFormat.format(rocket.getAltitude()), 10, 140);
			
			g.setFont(new Font("Serif", Font.BOLD, 18));
			g.drawString("Time: " + numberFormat.format(rocket.getTime()), 10, 160);
			
			g.setFont(new Font("Serif", Font.BOLD, 18));
			g.drawString("Speed: "  + numberFormat.format(rocket.getySpeed()), 10, 180);
			
			//Clouds
			g.setColor(Color.WHITE);
			
			for(int i = 0; i < 150; i = i+50) {
				g.fillOval(i, 50, 75, 50);
			}
			
			for(int i = 175; i < 325; i = i+50) {
				g.fillOval(i, 50, 75, 50);
			}
			
			for(int i = 350; i < 500; i = i+50) {
				g.fillOval(i, 50, 75, 50);
			}
		
			//Moves and redraws rocket
			rocket.move();
			rocket.draw(g);
			
			//Rocket will launch for 162 seconds
			if(rocket.getTime() < rocket.getBurnTime()) {
			repaint();
			}
		}
	}

	
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Falcon9LiftOff");
		frame.setSize(width, height);
		frame.setLocation(200,0);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new Falcon9LiftOff());
		frame.setVisible(true);
	}
		
}

