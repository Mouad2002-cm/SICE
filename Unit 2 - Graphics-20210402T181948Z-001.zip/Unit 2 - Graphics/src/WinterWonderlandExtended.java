import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class WinterWonderlandExtended extends JPanel {


	public static final int WIDTH = 800;
	public static final int HEIGHT = 600;

	public void paintComponent (Graphics g)
	{

		drawBackground(g);
		drawGround(g);
		
		Color snowColor = Color.WHITE;
		for(int i = 0; i < 1000; i++) {
			int x = ((int)(Math.random() * 800));
			int y = ((int)(Math.random() * 525 + 75));
			Snow snow = new Snow(x, y, 5, 5, snowColor);
			snow.draw(g);
		}
		
		drawHouse(g);
		drawClouds(g);
		drawFence(g);
		writeMessage(g);
		drawTree(g);
		
		Snowflake[] spes = new Snowflake[100];
		for (int i = 0; i < spes.length; i++) {
			spes[i] = new Snowflake((int)(Math.random() * 800), (int)(Math.random() * 525 + 75));
			spes[i].draw(g);
		}
	}
	
	public static void drawBackground(Graphics g) {

		g.setColor(Color.CYAN.brighter().brighter().brighter());
		g.fillRect(0, 0, 800, 600);
	}


	public static void drawGround(Graphics g) {

		g.setColor(Color.WHITE);
		g.fillRect(0, 450, 800, 600);
	}


	public static void drawHouse(Graphics g) {
		
		// House
		g.setColor(new Color(50, 50, 50));
		g.fillRect(100, 300, 150, 150);
		
		// Door
		g.setColor(Color.GRAY);
		g.fillRect(155, 405, 35, 45);

		// Roof - Connects points (75, 200),  (175, 150),  and (275, 200)
		int[] xPoints = {50, 175, 300};
		int[] yPoints = {300, 225, 300};
		g.fillPolygon(xPoints, yPoints, 3);
		
		//Window
		g.setColor(Color.YELLOW);
		g.fillRect(125, 325, 40, 40);
		
		g.setColor(Color.YELLOW);
		g.fillRect(185, 325, 40, 40);
		
		
	}
	
	
	public static void drawClouds(Graphics g) {
		g.setColor(Color.WHITE);
		
		for(int i = 100; i < 300; i = i+50) {
			g.fillOval(i, 50, 75, 50);
		}
		
		for(int i = 350; i < 550; i = i+50) {
			g.fillOval(i, 50, 75, 50);
		}
		
		for(int i = 600; i < 750; i = i+50) {
			g.fillOval(i, 50, 75, 50);
		}
	}
	
	public static void drawFence(Graphics g) {
		
		// Vertical lines for fence
		for (int x = 0; x < 360; x += 70) {
			g.drawLine(x, 375, x, 475);
		}
		// Horizontal lines for fence
		g.drawLine(0, 395, 350, 395);
		g.drawLine(0, 430, 350, 430);

	}
	
	
	public static void writeMessage(Graphics g) {
		
		g.setColor(Color.RED);
		g.setFont(new Font("Serif", Font.BOLD, 30));
		g.drawString("Winter Wonderland Extended!", 35, 35);
		
	}
	
	public static void drawTree(Graphics g) {
		
		//Tree Stump
		g.setColor(new Color(51, 25,1));
		g.fillRect(500, 375, 50, 75);
						
		//Tree
		g.setColor(Color.GREEN);
		int[] xPoints = {450, 525, 600};
		int[] yPoints = {375, 300, 375};
		g.fillPolygon(xPoints, yPoints, 3);
		
		int[] x2Points = {450, 525, 600};
		int[] y2Points = {325, 250, 325};
		g.fillPolygon(x2Points, y2Points, 3);
	}
	
	
	




	//Driver
	public static void main (String[] args)
	{
		JFrame frame = new JFrame("WinterWonderlandExtended");
		frame.setSize(WIDTH + 18, HEIGHT + 47);		// You need the +19 and +48 for the padding in the frame
		frame.setLocation(100, 50);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new WinterWonderlandExtended());
		frame.setVisible(true);
	}
	
}


 
