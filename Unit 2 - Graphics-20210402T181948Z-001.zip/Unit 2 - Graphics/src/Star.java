import java.awt.Color;
import java.awt.Graphics;

public class Star {

	private int x;
	private int y;
	private int width;
	private int height;
	private Color color;
	private int ySpeed;
	private int xSpeed;
	
	public Star (int x, int y, int width, int height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
		this.ySpeed = 0;
		this.xSpeed = 0;
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		int[] xPoints = {x, x+(1*width/4), x, x+(1*width/2), x+width, x+(3*width/4), x+width, x+(1*width/2)};
		int[] yPoints = {y, y+(1*height/2), y+height, y+(3*height/4), y+height, y+(1*height/2), y, y+(1*height/4)};
		g.fillPolygon(xPoints, yPoints, 8);
		
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getX() {
		return x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public int getY() {
		return y;
	}
	
	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}
	
	public int getxSpeed() {
		return xSpeed;
	}
	
	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}
	
	public int getySpeed() {
		return ySpeed;
	}
	
	public void move(int rightEdge) {
		setX(getX() + getxSpeed());
	}
}