import java.awt.Color;
import java.awt.Graphics;

public class Snow {

	private int x;
	private int y;
	private int width;
	private int height;
	private Color color;
	
	public Snow(int ax, int ay, int awidth, int aheight, Color acolor) {
		this.x = ax;
		this.y = ay;
		this.width = awidth;
		this.height = aheight;
		this.color = acolor;
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.fillOval(x, y, width, height);
	}
}
