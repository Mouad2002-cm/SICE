import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GraphicsDemo extends JPanel {
	
	public void paintComponent(Graphics g) {
		
		//Draw a background
		g.setColor(Color.BLUE.darker());
		g.fillRect(0, 0, 750, 500);
		
		//Add a rectangle
		g.setColor(new Color(55, 55, 55));
		g.fillRect(50, 50, 100, 75);
		
		//Add oval 
		g.setColor(Color.MAGENTA);
		g.fillOval(100, 200, 60, 80);
		
		//Draw line
		g.drawLine(400, 300, 600, 300);
		
		//Add text
		g.setColor(Color.ORANGE);
		g.setFont(new Font("Kartika", Font.BOLD, 50));
		g.drawString("Hello Graphics", 325, 250);
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Graphics Demo");
		frame.setSize(750,500);
		frame.setLocation(50,0);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new GraphicsDemo());
		frame.setVisible(true);
	}
	

}