import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class BouncingBall extends JPanel{
	
	//Sets the width and height of frame
	private static final int width = 500;
	private static final int height = 500;
	
	//declare global variables
	private BufferedImage image;
	private Graphics g;
	private Timer timer;
	private Ball[] balls;
	
	public BouncingBall() {
		//set Buffered Image and Graphics objects
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		g = image.getGraphics();
		
		GraphicsUtilities.drawBackground(g, Color.WHITE, width, height);
		balls = new Ball[10];
		for (int i = 0; i < balls.length; i++) {
//			int y = (int)(Math.random()*height);
			Color color = new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
			balls[i] = new Ball(0, height/2, 50, color);
			balls[i].setxSpeed(5);
			balls[i].setySpeed(-15);
			balls[i].draw(g);
		}
	
		
		
		//Set and start timer
		timer = new Timer(10, new TimerListener());
		timer.start();
		
	}
	
	//TimerListener that is called by the timer in the constructor
		public class TimerListener implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent a) {
				//Ball ball = new Ball(200, 200, 100, Color.DARK_GRAY);
				GraphicsUtilities.drawBackground(g, Color.WHITE, width, height);
				
			for(int i = 0; i < balls.length; i++) {
				balls[i].move(width, height);
				balls[i].draw(g);
			}
				repaint();
			}
		}
	
	//Paint Component - DO NOT ALTER
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
	}

	
	public static void main(String[] args) {
		JFrame frame = new JFrame("BouncingBall"); //name in the header of frame; rename to match program
		frame.setSize(width, height); //sets size of window
		frame.setLocation(100, 100); //sets location of your frame on screen
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new BouncingBall()); 
		frame.setVisible(true);
	}

}
