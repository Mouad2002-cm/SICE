// House.java
// ITCS

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class House extends JPanel
{
	public static final int WIDTH = 500;
	public static final int HEIGHT = 400;

	public void paintComponent (Graphics g)
	{
		drawBackground(g);
		drawGround(g);
		drawHouse(g);
		drawSun(g);
		drawClouds(g);
		drawFence(g);
		writeMessage(g);
	
	}

	public static void drawBackground(Graphics g) {

		g.setColor(Color.BLUE.brighter().brighter());
		g.fillRect(0, 0, 500, 400);
	}


	public static void drawGround(Graphics g) {

		g.setColor(Color.GREEN);
		g.fillRect(0, 300, 500, 400);
	}


	public static void drawHouse(Graphics g) {
		
		// House
		g.setColor(Color.MAGENTA);
		g.fillRect(100, 175, 125, 125);
		
		// Door
		g.setColor(Color.BLACK);
		g.fillRect(145, 255, 35, 45);

		// Roof - Connects points (75, 200),  (175, 150),  and (275, 200)
		int[] xPoints = {75, 163, 250};
		int[] yPoints = {175, 125, 175};
		g.fillPolygon(xPoints, yPoints, 3);	
	}
	
	
	public static void drawSun(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillOval(400, 50, 50, 50);
	}
	
	
	public static void drawClouds(Graphics g) {
		g.setColor(Color.WHITE);
		
		for(int i = 175; i < 300; i = i+25) {
			g.fillOval(i, 50, 75, 50);
		}
	}
	
	public static void drawFence(Graphics g) {
		
		// Vertical lines for fence
		for (int x = 0; x < 500; x += 70) {
			g.drawLine(x, 275, x, 375);
		}
		// Horizontal lines for fence
		g.drawLine(0, 325, 500, 325);
		g.drawLine(0, 360, 500, 360);

	}
	
	public static void writeMessage(Graphics g) {
		
		g.setColor(Color.DARK_GRAY);
		g.setFont(new Font("Serif", Font.BOLD, 30));
		g.drawString("Home, Sweet Home.", 35, 35);
		
	}




	//Driver
	public static void main (String[] args)
	{
		JFrame frame = new JFrame("Home, Sweet Home");
		frame.setSize(WIDTH + 18, HEIGHT + 47);		// You need the +19 and +48 for the padding in the frame
		frame.setLocation(100, 50);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new House());
		frame.setVisible(true);
	}
}