import java.awt.Color;

public class GravityBall extends Ball {

	// 1. Declaration of Variables
	
	private double xAcceleration = 0; //acceleration in the x direction
	private double yAcceleration = 9.8; //acceleration in the y direction
	
	// 2. Creates a method that takes in x, y, diameter, and color and calls Ball
	
	public GravityBall(double x, double y, double diameter, Color color) {
		super(x, y, diameter, color);
	}

	
	// 3. Create getters and setters for all private variables
	
	public void setXAcceleration(double xAcceleration) {
		this.xAcceleration = xAcceleration;
	}
	
	public double getXAcceleration() {
		return xAcceleration;
	}
	
	public void setYAcceleration(double yAcceleration) {
		this.yAcceleration = yAcceleration;
	}
	
	public double getYAcceleration() {
		return yAcceleration;
	}
	
	
	// 4. Given an initial velocity and angle of launch a xSpeed and ySpeed are calculated
	/*
	 * @param angle - angle given by the user 
	 * @param speed - inputed velocity that will
	 * @param xSpeed - x portion of the velocity
	 * @param ySpeed - y portion of the velocity
	 * be split into x and y components
	 */
	
	public void setInitialVelocity(int speed, int angle) {
		double radangle = (Math.toRadians(angle));
		setxSpeed(speed * Math.cos(radangle));
		setySpeed(speed * Math.sin(radangle));
	}

	
	// 5. Create a launch method that takes in right edge, bottom edge, and delta time
	public void launch(int rightEdge, int bottomEdge, double deltaTime) {
		setxSpeed(getxSpeed()+getXAcceleration()*(deltaTime/1000));
		setX(getX() + getxSpeed());
		setySpeed(getySpeed()+getYAcceleration()*(deltaTime/1000));
	    setY(getY() + getySpeed());
		
		//right edge
		if(rightEdge - getX() < getRadius()) {
			setX(rightEdge - getRadius());
			setxSpeed(getxSpeed() * -1);
		}
		
		//left edge
		if(getX() <= getRadius()) {
			setX(getRadius());
			setxSpeed(getxSpeed() * -1);
		}
		
		//bottom edge
		if(bottomEdge - getY() < getRadius()) {
			setY(bottomEdge - getRadius());
			setySpeed(getySpeed() * -1);
		}
		
		//top edge
		if(getY() <= getRadius()) {
			setY(getRadius());
			setySpeed(getySpeed() * -1);
		}
		
	}
	
}

