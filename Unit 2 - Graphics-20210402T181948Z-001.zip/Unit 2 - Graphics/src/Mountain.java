import java.awt.Color;
import java.awt.Graphics;

public class Mountain {
	
	private int x;
	private int y;
	private int width;
	private int height;
	private Color color;
	
	/**
	 * Creates a mountain with the center of the base defined as (x,y)
	 * @param x - x-coord of the center of the base
	 * @param y - y-coord of the center of the base
	 * @param width - total base width of the mountain
	 * @param height - total height base to peak of mountain
	 * @param color - color of mountain
	 */

	public Mountain(int x, int y, int width, int height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}
	
	
	/**
	 * Draws a mountain
	 * @param g - graphics object
	 */
	
	public void draw(Graphics g) {
		g.setColor(color);
		int[] xPoints = {x-width/2,x,x+width/2};
		int[] yPoints = {y,y-height,y};
		g.fillPolygon(xPoints, yPoints, 3);
		
	}

}
