import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class AnimationShell extends JPanel{
	
	//Sets the width and height of frame
	private static final int width = 500;
	private static final int height = 500;
	
	//declare global variables
	private BufferedImage image;
	private Graphics g;
	private Timer timer;
	//TODO: declare any other
	
	public AnimationShell() {
		//set Buffered Image and Graphics objects
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		
	}
	
	//Paint Component - DO NOT ALTER
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		g = image.getGraphics();
		
		//TODO: Code to set up initial image and any objects you plan to animate
		
		
		
		
		
		//Set and start timer
		timer = new Timer(10, new TimerListener());
		timer.start();
	}
	
	//TimerListener that is called by the timer in the constructor
	public class TimerListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO move any objects to be animated
			
			
			
			repaint();
			
		}
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("AnimationShell"); //name in the header of frame; rename to match program
		frame.setSize(width, height); //sets size of window
		frame.setLocation(100, 100); //sets location of your frame on screen
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new AnimationShell()); //TODO: Change to match class name
		frame.setVisible(true);
	}

}
