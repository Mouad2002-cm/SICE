	import java.awt.Color;
	import java.awt.Graphics;

	import javax.swing.JFrame;
	import javax.swing.JPanel;


@SuppressWarnings("serial")
public class RocketGarden extends JPanel {


		public static final int WIDTH = 800;
		public static final int HEIGHT = 600;

		public void paintComponent (Graphics g)
		{
			drawBackground(g);
			drawGround(g);
			drawClouds(g);
			
			Rocket smallRocket = new Rocket(100, 200, 35, 115, Color.DARK_GRAY);
			smallRocket.draw(g);
		
			smallRocket.setX(700);
			smallRocket.setY(200);
			smallRocket.draw(g);
			
			Rocket rocket = new Rocket(300, 300, 75, 200, Color.RED);
			rocket.draw(g);
			
			rocket.setX(450);
			rocket.setY(300);
			rocket.draw(g);
		}
		
		
		public static void drawBackground(Graphics g) {

			g.setColor(Color.BLUE.darker().darker());
			g.fillRect(0, 0, 800, 600);
		}
		


		public static void drawGround(Graphics g) {

			g.setColor(Color.BLACK);
			g.fillRect(0, 500, 800, 600);
		}
		
		public static void drawClouds(Graphics g) {
			g.setColor(Color.WHITE);
			
			for(int i = 100; i < 300; i = i+50) {
				g.fillOval(i, 50, 75, 50);
			}
			
			for(int j = 350; j < 550; j = j+50) {
				g.fillOval(j, 50, 75, 50);
			}
			
			for(int k = 600; k < 750; k = k+50) {
				g.fillOval(k, 50, 75, 50);
			}
		}



		public static void main (String[] args)
		{
			JFrame frame = new JFrame("RocketGarden");
			frame.setSize(WIDTH + 18, HEIGHT + 47);		// You need the +19 and +48 for the padding in the frame
			frame.setLocation(100, 50);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setContentPane(new RocketGarden());
			frame.setVisible(true);
		}
	}

