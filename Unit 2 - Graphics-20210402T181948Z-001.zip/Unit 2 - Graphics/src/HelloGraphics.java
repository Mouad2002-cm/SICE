import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class HelloGraphics extends JPanel {
	
	public void paintComponent(Graphics g) {
		
		//Draw a background
		g.setColor(Color.BLUE);
		g.fillRect(0, 0, 1000, 800);
		
		//Add a rectangle
		g.setColor(new Color(55, 55, 55));
		g.fillRect(50, 50, 300, 300);
		
		//Add oval 
		g.setColor(Color.RED);
		g.fillOval(500, 200, 350, 350);
		
		//Draw line
		g.drawLine(10, 0, 10, 800);
		g.drawLine(0, 560, 1000, 560);
		
		//Add text
		g.setColor(Color.GREEN);
		g.setFont(new Font("Serif", Font.BOLD, 50));
		g.drawString("I love shapes", 650, 100);
		
		for(int i = 50; i < 400; i = i+150) {
			g.setColor(Color.ORANGE);
			g.fillOval(i, 600, 150, 150);
		}
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Graphics Demo");
		frame.setSize(1000,800);
		frame.setLocation(0,0);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new HelloGraphics());
		frame.setVisible(true);
	}
	

}