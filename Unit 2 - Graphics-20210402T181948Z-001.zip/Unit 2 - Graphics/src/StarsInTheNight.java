import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class StarsInTheNight extends JPanel {

	private static final int width = 500;
	private static final int height = 500;
	
	private BufferedImage image;
	private Graphics g;
	private Timer timer;
	private Star[] stars;
	
	public StarsInTheNight() {
		
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		g = image.getGraphics();
		
		GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
		
	  stars = new Star[10];
		for (int i = 0; i < stars.length; i++) {
			stars[i] = new Star((int)(Math.random() * width),(int)(Math.random() * 100), 50, 50, Color.YELLOW);
			stars[i].setxSpeed(1);
			stars[i].draw(g);
		}
		
		timer = new Timer(5, new TimerListener());
		timer.start();
		
	}
	
	private class TimerListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
		GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
			
		for(int i = 0; i < stars.length; i++) { 
			stars[i].move(width);
			stars[i].draw(g);
		}
			
			repaint();
		
	}
	}

	
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("StarsInTheNight");
		frame.setSize(width, height);
		frame.setLocation(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new StarsInTheNight());
		frame.setVisible(true);
	}
	
	
}