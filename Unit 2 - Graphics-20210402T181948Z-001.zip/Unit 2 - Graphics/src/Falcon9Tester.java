import java.awt.Color;

public class Falcon9Tester {

	public static void main(String[] args) {

		Falcon9 rocket = new Falcon9(0, 0, 10, 10, Color.BLACK);
		rocket.setDeltaTime(1);
		@SuppressWarnings("unused")
		int iterations = (int) (rocket.getBurnTime()/rocket.getDeltaTime());

		while(rocket.getTime() <= rocket.getBurnTime()) {

			System.out.println("" + rocket.getTime() + "," + rocket.getMassR()+ "," + rocket.getgAcceleration()+ "," + rocket.getyAcceleration() + "," + rocket.getySpeed()+ "," + rocket.getY());
			rocket.move();
		}

	}

}