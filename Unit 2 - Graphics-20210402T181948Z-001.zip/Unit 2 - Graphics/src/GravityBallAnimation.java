import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class GravityBallAnimation extends JPanel{
	
	//Sets the width and height of frame
	private static final int width = 500;
	private static final int height = 500;
	private static final int deltaTime = 10;
	
	
	//declare global variables
	private BufferedImage image;
	private Graphics g;
	private Timer timer;
	private GravityBall ball;
	
	public GravityBallAnimation() {
		//set Buffered Image and Graphics objects
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		g = image.getGraphics();
		
		GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
		ball = new GravityBall(0,height,25,Color.RED);
		ball.draw(g);
		ball.setInitialVelocity(10, 60);
		ball.setXAcceleration(0);
		ball.setYAcceleration(9.8);
		
		
		
		//Set and start timer
		timer = new Timer(deltaTime, new TimerListener());
		timer.start();
		
	}
	
	//TimerListener that is called by the timer in the constructor
		public class TimerListener implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent a) {
				//Ball ball = new Ball(200, 200, 100, Color.DARK_GRAY);
				GraphicsUtilities.drawBackground(g, Color.BLACK, width, height);
				ball.launch(width, height, deltaTime);
				ball.draw(g);
				
				repaint();
			}
		}
	
	//Paint Component - DO NOT ALTER
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
	}

	
	public static void main(String[] args) {
		JFrame frame = new JFrame("GravityBallAnimation"); //name in the header of frame; rename to match program
		frame.setSize(width, height); //sets size of window
		frame.setLocation(100, 100); //sets location of your frame on screen
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new GravityBallAnimation()); 
		frame.setVisible(true);
	}

}
