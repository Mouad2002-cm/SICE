import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Rocket {

	private double x;
	private double y;
	private double width;
	private double height;
	private Color color;
	private double ySpeed;
	private double xSpeed;
	
	public Rocket(double x, double y, double width, double height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
		this.ySpeed = 0;
		this.xSpeed = 0;
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect((int)x,(int)y,(int)width,(int)height);
		g.fillRect((int)x,(int)y,(int)width,(int)height);
		
		int[] xPoints = {(int)(x),(int)(x+width/2),(int)(x+width)};
		int[] yPoints = {(int)(y),(int)(y-height/3),(int)(y)};
		g.fillPolygon(xPoints, yPoints, 3);
		
		g.drawOval((int)(x+width/4),(int)(y+height/4),(int)(width/8),(int)(height/8));
		
		int[] finxPoints = {(int)(x-width/4),(int)(x+width/2),(int)(x+5*width/4)};
		int[] finyPoints = {(int)(y+height),(int)(y+height/2),(int)(y+height)};
		g.fillPolygon(finxPoints, finyPoints, 3);
		
		g.setColor(Color.BLACK);
		g.setFont(new Font("Serif", Font.BOLD, 12));
		g.drawString("Hawk", (int)(x+width/16), (int)(y+5*height/6));
		
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public double getX() {
		return x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public double getY() {
		return y;
	}
	
	public void setxSpeed(double xSpeed) {
		this.xSpeed = xSpeed;
	}
	
	public double getxSpeed() {
		return xSpeed;
	}
	
	public void setySpeed(double ySpeed) {
		this.ySpeed = ySpeed;
	}
	
	public double getySpeed() {
		return ySpeed;
	}
	
	public void move(int topEdge) {
		setY(getY() + getySpeed());
	}
}
