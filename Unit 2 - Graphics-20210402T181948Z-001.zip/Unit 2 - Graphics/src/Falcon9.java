import java.awt.Color;

public class Falcon9 extends Rocket{
	
	private double massR;
	private double thrust;
	private double deltaM;
	private double fuelMass;
	private double burnTime;
	private double time;
	private double deltaTime;
	private double yAcceleration;
	private double gAcceleration;
	private double altitude;
	
	//Constructor that calls the super rocket class and sets initial conditions
	public Falcon9(double x, double y, double width, double height, Color color) {
		super(x, y, width, height, color);
		
		//Masses
		massR = 541300;
		fuelMass = 398900;
		
		thrust = 6806000;
		
		//Times
		burnTime = 162;
		deltaTime = 5;
		time = 0;
		
		//Accelerations
		yAcceleration = 0;
		gAcceleration = 9.8;
		
		altitude = 0;
		
	}

	//Getters and setters
	public double getMassR() {
		return massR;
	}

	public void setMassR(double massR) {
		this.massR = massR;
	}

	public double getThrust() {
		return thrust;
	}

	public void setThrust(double thrust) {
		this.thrust = thrust;
	}

	public double getDeltaM() {
		return deltaM;
	}

	public void setDeltaM(double deltaM) {
		this.deltaM = deltaM;
	}

	public double getFuelMass() {
		return fuelMass;
	}

	public void setFuelMass(double fuelMass) {
		this.fuelMass = fuelMass;
	}

	public double getBurnTime() {
		return burnTime;
	}

	public void setBurnTime(double burnTime) {
		this.burnTime = burnTime;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}

	public double getDeltaTime() {
		return deltaTime;
	}

	public void setDeltaTime(double deltaTime) {
		this.deltaTime = deltaTime;
	}

	public double getyAcceleration() {
		return yAcceleration;
	}

	public void setyAcceleration(double yAcceleration) {
		this.yAcceleration = yAcceleration;
	}

	public double getgAcceleration() {
		return gAcceleration;
	}

	public void setgAcceleration(double gAcceleration) {
		this.gAcceleration = gAcceleration;
	}
	
	public double getAltitude() {
		return altitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	//move method
	public void move() {
		//Update mass from burning fuel
		setDeltaM(fuelMass/burnTime);
		setMassR(getMassR() - (getDeltaM() * getDeltaTime()));
		//Updates acceleration by dividing net force in the y by mass
		setyAcceleration((thrust - (getMassR() * getgAcceleration()))/getMassR());
		//Updates y-speed by adding speed to the acceleration
		setySpeed(getySpeed()+(getyAcceleration()*deltaTime));
		//Updates position based on velocity
	    setAltitude(getAltitude() + (getySpeed()*getDeltaTime()));
	    setY(700 - getAltitude());
	    //Updates time
	    setTime(getTime() + getDeltaTime());
	}
}
