import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Meme extends JPanel{
	
	private static final int width = 500;
	private static final int height = 500;
	
	private BufferedImage bufferedImage;
	
	public Meme() {
		bufferedImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		Graphics g = bufferedImage.getGraphics();
		
		GraphicsUtilities.drawBackground(g,Color.WHITE,500,500);
		
		ImageIcon image = new ImageIcon("JOEBURROW.png");
		g.drawImage(image.getImage(),0,0,width,height,null);
		
	}

	public void paintComponent(Graphics g) {
		g.drawImage(bufferedImage, 0, 0, width, height, null);
		writeMessage(g);
	}
	
	public static void writeMessage(Graphics g) {
		
		g.setColor(Color.BLACK);
		g.setFont(new Font("Arial", Font.BOLD, 30));
		g.drawString("I'm going to tell my son", 75, 35);
		
		g.drawString("This was Joe Burrow", 85, 450);
		
	}
	
	
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame("Imported Image Example");
		frame.setSize(500, 500);
		frame.setLocation(300,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new Meme());
		frame.setVisible(true);
		
	}
	
}
